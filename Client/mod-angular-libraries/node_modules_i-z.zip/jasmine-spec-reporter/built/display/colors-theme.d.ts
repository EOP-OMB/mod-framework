interface String {
    successful: string;
    failed: string;
    pending: string;
    prettyStacktraceFilename: string;
    prettyStacktraceLineNumber: string;
    prettyStacktraceColumnNumber: string;
    prettyStacktraceError: string;
}
