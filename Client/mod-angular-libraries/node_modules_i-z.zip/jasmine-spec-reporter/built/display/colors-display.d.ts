import { Configuration } from "../configuration";
export declare function init(configuration: Configuration): void;
