"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Configuration = exports.StacktraceOption = void 0;
var StacktraceOption;
(function (StacktraceOption) {
    StacktraceOption["NONE"] = "none";
    StacktraceOption["RAW"] = "raw";
    StacktraceOption["PRETTY"] = "pretty";
})(StacktraceOption = exports.StacktraceOption || (exports.StacktraceOption = {}));
var Configuration = /** @class */ (function () {
    function Configuration() {
    }
    return Configuration;
}());
exports.Configuration = Configuration;
//# sourceMappingURL=configuration.js.map