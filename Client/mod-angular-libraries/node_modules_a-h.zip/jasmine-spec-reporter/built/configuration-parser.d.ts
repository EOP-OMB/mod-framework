import { Configuration } from "./configuration";
export declare function parse(conf?: Configuration): Configuration;
